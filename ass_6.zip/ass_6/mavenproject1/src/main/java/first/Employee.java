/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package first;

/**
 *
 * @author 6student107
 */
public class Employee {
    public int number;
    public String name;
    public float salary;
    public Employee(int number,String name,float salary){
        this.number=number;
        this.name=name;
        this.salary=salary;
    }
}
