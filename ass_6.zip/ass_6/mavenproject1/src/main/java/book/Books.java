/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package book;
/**
 *
 * @author 6student107
 */
public class Books {
    public String name;
    public float price;
    public String author;
    public Books(String name,float price,String author){
        this.name = name;
        this.price =price;
        this.author=author;
    }
}
