/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author 6student107
 */
package TYBCA;

public class Marks extends Subject {
    private float m1;
    private float m2;
    private float m3;

    public Marks(String sub1, String sub2, String sub3, float m1, float m2, float m3) {
        super(sub1, sub2, sub3);
        this.m1 = m1;
        this.m2 = m2;
        this.m3 = m3;
    }

    public void cal() {
        System.out.println(super.sub1 + " = " + m1);
        System.out.println(super.sub2 + " = " + m2);
        System.out.println(super.sub3 + " = " + m3);

        float total = m1 + m2 + m3;
        System.out.println("Total marks = " + total);
        System.out.println("Percentage = " + (total / 300) * 100 + "%");  // Assuming 100 marks per subject
    }
}



