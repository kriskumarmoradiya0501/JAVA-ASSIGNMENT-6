/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package second;
import first.*;
/**
 *
 * @author 6student107
 */
public class Manager extends Employee{
    public String dep_name;
    public float incentive;
    public Manager(int number,String name,float salary,String dep_name,float incentive){
        super(number,name,salary);
        this.dep_name=dep_name;
        this.incentive=incentive;
    }
    public void display(){
        System.out.println("Employee Number : "+super.number);
        System.out.println("Employee Name : "+super.name);
        System.out.println("Employee Salary : "+super.salary);
        System.out.println("Department Name : "+dep_name);
        System.out.println("Incentive : "+incentive);
        System.out.println("Gross Salary : "+(super.salary+incentive));
    }
}
