/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;

/**
 *
 * @author 6student107
 */
public class Q_4 {
    public static void main(String[] args) {
        int primitiveInt = 10;
        Integer wrappedInt = primitiveInt; 
        System.out.println("Auto-boxed Integer: " + wrappedInt);

        Integer anotherWrappedInt = 20;
        int anotherPrimitiveInt = anotherWrappedInt; 
        System.out.println("Un-boxed int: " + anotherPrimitiveInt);

        Integer num1 = 15;
        Integer num2 = 25;
        Integer sum = num1 + num2; 
        System.out.println("Sum (auto-boxed): " + sum);

        int result = num1 + num2; 
        System.out.println("Result (un-boxed): " + result);

        Integer maxInt = Integer.MAX_VALUE;
        System.out.println("Maximum value of Integer: " + maxInt);
        System.out.println("Parsed Integer from String: " + Integer.parseInt("12345"));
    }
}

