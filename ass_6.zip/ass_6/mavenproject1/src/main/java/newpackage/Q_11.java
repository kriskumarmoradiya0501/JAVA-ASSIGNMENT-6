/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 6student107
 */
package newpackage;

import TYBCA.Marks;

public class Q_11 {
    public static void main(String[] args) {
        Marks m = new Marks("Maths", "Physics", "Biology", 40.0f, 50.0f, 60.0f);
        m.cal();
    }
}
