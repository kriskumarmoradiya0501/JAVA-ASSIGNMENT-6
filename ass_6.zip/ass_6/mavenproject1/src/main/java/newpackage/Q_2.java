/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import second.*;
/**
 *
 * @author 6student107
 */
public class Q_2 {
    public static void main(String[] args) {
        Manager m = new Manager(130,"Mantri",80000.0f,"CMPICA",5000.0f);
        m.display();
    }
}
