/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import java.util.Scanner;
import book.*;
class Detail extends Books{
    public Detail(String name,float price,String author){
        
        
        super(name,price,author);
    }
    public void display(){
        System.out.println("Book name : "+super.name);
        System.out.println("Book Price : "+super.price);
        System.out.println("Author Name : "+super.author);
    }
}
/**
 *
 * @author 6student107
 */
public class Q_3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter Name of Book : ");
        String name = s.nextLine();
        System.out.print("Enter Name of Book : ");
        float price = s.nextFloat();
        s.nextLine();
        System.out.print("Enter Name of Book : ");
        String author = s.nextLine();
        Detail d = new Detail(name,price,author);
        d.display();
    }
}
